# PacmanGame
I built the pacman game without the ai for pacman

I used processing to write this code and if you wanna run it then you will need processing
https://processing.org/

