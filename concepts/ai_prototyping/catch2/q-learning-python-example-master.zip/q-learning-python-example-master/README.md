# q-learning-python-example
The video demonstration as well as a little code explanation is available in youtube:
https://www.youtube.com/watch?v=o5GiQkClbAY


* Requirements:
Pygame,
Numpy

* To Run:
In a console, go to the project directory and issue: 'python main.py'\

* Only the demo, without the code presentation: https://youtu.be/gS8WFQHtsj0
