package main.analysis;

import grid.GridGraph;

import java.util.ArrayList;

import algorithms.datatypes.Point;

public class ExplorableRegionAnalysis {
    
    public ExplorableRegionAnalysis(GridGraph gridGraph, ArrayList<Point> connectedSet) {
        
    }
    
}