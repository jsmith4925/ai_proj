package draw;

import java.awt.Graphics;

public interface Drawer {

    public abstract void draw(Graphics g);

}