package grid;

public class StartGoalPoints {
	public final int sx, sy, ex, ey;

	public StartGoalPoints(int sx, int sy, int ex, int ey) {
		this.sx = sx;
		this.sy = sy;
		this.ex = ex;
		this.ey = ey;
	};
}
