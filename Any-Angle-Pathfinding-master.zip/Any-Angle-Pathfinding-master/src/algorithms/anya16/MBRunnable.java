package algorithms.anya16;

/**
 * Created by Dindar on 21.9.2014.
 */
public interface MBRunnable {
    public void run();
    public void cleanUp();
}
